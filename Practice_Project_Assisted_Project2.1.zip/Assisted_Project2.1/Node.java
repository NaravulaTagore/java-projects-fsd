package phase1_assisted_practice2;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node head;

    // Function to insert a new node in a sorted circular linked list
    void insertSorted(int newData) {
        Node newNode = new Node(newData);

        // Case 1: If the list is empty
        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else if (newData <= head.data) {
            // Case 2: If the new node's data is less than or equal to the head's data
            Node last = getLastNode();
            last.next = newNode;
            newNode.next = head;
            head = newNode;
        } else {
            // Case 3: Insert the new node at the appropriate position
            Node current = head;
            while (current.next != head && current.next.data < newData) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    // Function to get the last node in the circular linked list
    private Node getLastNode() {
        Node temp = head;
        while (temp.next != head) {
            temp = temp.next;
        }
        return temp;
    }

    // Function to display the circular linked list
    void displayList() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }



    public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();

        // Inserting elements in sorted order
        list.insertSorted(10);
        list.insertSorted(20);
        list.insertSorted(30);
        list.insertSorted(40);

        System.out.println("Original Circular Linked List:");
        list.displayList();

        // Inserting a new element
        int newData = 25;
        list.insertSorted(newData);

        System.out.println("Circular Linked List after inserting " + newData + ":");
        list.displayList();
    	}
	}

