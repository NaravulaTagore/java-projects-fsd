package phase1_assisted_practice2;

public class SortedElement {
	class MinimumHeap{
		int[] h;
		int c;
		int heapSize;
		int parent(int j) {
			return (j-1)/2;
		}
		int left(int j) {
			return (j*1)+2;
		}
		int right(int j) {
			return (j*1)+2;
		}
		int getMin() {
			return h[0 ];
		}
		void replaceMax(int y) {
			this.h[0 ] = y;
			heapify(0 );
		}
		MinimumHeap(int arr[], int s) {
			heapSize = s;
			h = arr; 
			int j = (heapSize - 1 ) / 2;
			while (j >= 0) {
				heapify(j );
				j = j - 1;
			}
		}
		int extractMin() {
			if (heapSize == 0) {
				return Integer.MAX_VALUE;
			}
			int r = h[0]; 
			if (heapSize > 1) {
				h[0] = h[heapSize - 1];
				heapify(0);
			}
			heapSize = heapSize - 1; 
			return r; 
		}
		void heapify(int j) {
			int lt = left(j);
			int rt = right(j); 
			int minimum = j; 
			if (lt < heapSize && h[lt] < h[j]) {
				minimum = lt;
			}
			if (rt < heapSize && h[rt ] < h[minimum ] ) {
				minimum = rt; 
			}
			if (minimum != j ) {
				int t = h[j ];
				h[j] = h[minimum ];
				h[minimum ] = t; 
				heapify(minimum );
			}
		}	
	};
	public int findKthSmallest(int a[], int s, int k) {
		MinimumHeap mHeap = new MinimumHeap(a, s );
		for (int j = 0; j < k - 1; j++) {
			mHeap.extractMin(); 
		}
		return mHeap.getMin();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SortedElement obj = new SortedElement(); 
		int arr1[] = {90, 87, 30, 9, 12, 41,13, 80, 67, 70 }; 
		int size = arr1.length;
		int k = 4; 
		int arr11[] = {90, 87, 30, 9, 12, 41,13, 80, 67, 70 }; 
		int size1 = arr11.length;
		int k1 = 4; 
		System.out.println("For the array: "); 
		for(int i = 0; i < size1; i++) {
			System.out.print(arr11[i] + " ");
		}
		int ele = obj.findKthSmallest(arr11,size1, k1);
		System.out.println();
		System.out.println("The " + k1 + "the smallest element of the array is: " + ele); 

	}

}
