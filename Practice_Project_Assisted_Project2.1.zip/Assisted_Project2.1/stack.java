package phase1_assisted_practice2;

import java.util.*;
import java.util.Stack;

public class stack {

	public static void main(String args[])
	{
	// Creating an empty Stack
	Stack<String> stack = new Stack<String>();
	// Use add() method to add elements into the Stack
	stack.add("Welcome");
	stack.add("To");
	stack.add("MyApp");
	stack.add("4");
	stack.add("MyApp");
	// Displaying the Stack
	System.out.println("Stack: " + stack);
	// Inserting element at 3rd position
	stack.insertElementAt("Hello", 2);
	// Inserting element at last position
	stack.insertElementAt("World", 6);
	// Displaying the final Stack
	System.out.println("The final Stack is "+ stack);
	}
}
