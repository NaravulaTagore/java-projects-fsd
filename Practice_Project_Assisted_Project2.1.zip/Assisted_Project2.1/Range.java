package phase1_assisted_practice2;

import java.util.*;


public class Range {
public static int findSum(int L, int R)
{
ArrayList<Integer> arr = new ArrayList<>();
int i = 0;
int x = 2;
while (i <= R)
{
arr.add(i + x);
if (i + 1 <= R)
arr.add(i + 1 + x);
x = x * (-1);
i = i + 2;
}
int sum = 0;
for(i = L; i <= R; ++i)
sum += arr.get(i);
return sum;
}
public static void main(String[] args)
{
int L = 0, R = 5;
System.out.println(findSum(L, R));
}
}