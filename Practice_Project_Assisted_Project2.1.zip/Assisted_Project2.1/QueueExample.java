package phase1_assisted_practice2;

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {
    public static void main(String[] args) {
        // Creating a Queue using LinkedList
        Queue<Integer> queue = new LinkedList<>();

        // Inserting elements into the queue
        enqueue(queue, 10);
        enqueue(queue, 20);
        enqueue(queue, 30);
        enqueue(queue, 40);

        // Displaying the elements in the queue
        System.out.println("Elements in the queue: " + queue);

        // Removing elements from the queue
        dequeue(queue);
        dequeue(queue);

        // Displaying the elements in the queue after removal
        System.out.println("Elements in the queue after removal: " + queue);
    }

    // Function to insert an element into the queue
    private static void enqueue(Queue<Integer> queue, int element) {
        queue.add(element);
        System.out.println("Enqueued: " + element);
    }

    // Function to remove an element from the queue
    private static void dequeue(Queue<Integer> queue) {
        if (!queue.isEmpty()) {
            int removedElement = queue.poll();
            System.out.println("Dequeued: " + removedElement);
        } else {
            System.out.println("Queue is empty. Cannot dequeue.");
        }
    }
}